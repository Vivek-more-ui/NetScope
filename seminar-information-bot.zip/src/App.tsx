import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { NotificationProvider, useNotifications } from './context/NotificationContext.js';
import { Navbar } from './components/Navbar.js';
import { HomePage } from './pages/HomePage.js';
import { DiscoveryPage } from './pages/DiscoveryPage.js';
import { MyRegistrationsPage } from './pages/MyRegistrationsPage.js';
import { AiAssistantPage } from './pages/AiAssistantPage.js';
import { OrganizerPage } from './pages/OrganizerPage.js';
import { AdminPage } from './pages/AdminPage.js';
import { ProfilePage } from './pages/ProfilePage.js';
import { SeminarDetailModal } from './components/SeminarDetailModal.js';
import { RegistrationModal } from './components/RegistrationModal.js';
import { RegistrationTicketModal } from './components/RegistrationTicketModal.js';
import { Seminar, Registration } from './types/index.js';
import { api } from './services/api.js';
import { Bot, Sparkles, Heart } from 'lucide-react';

function AppContent() {
  const { user } = useAuth();
  const { refreshNotifications } = useNotifications();

  const [currentPage, setCurrentPage] = useState<string>('home');
  const [filterCategory, setFilterCategory] = useState<string | undefined>(undefined);

  // Seminars state
  const [allSeminars, setAllSeminars] = useState<Seminar[]>([]);
  const [registeredSeminarIds, setRegisteredSeminarIds] = useState<string[]>([]);

  // Modals state
  const [selectedSeminarForDetails, setSelectedSeminarForDetails] = useState<Seminar | null>(null);
  const [selectedSeminarForRegister, setSelectedSeminarForRegister] = useState<Seminar | null>(null);
  const [ticketToDisplay, setTicketToDisplay] = useState<Registration | null>(null);

  const loadAllData = useCallback(async () => {
    try {
      const [seminarsData, registrationsData] = await Promise.all([
        api.getSeminars(),
        api.getRegistrations({ userEmail: user.email }),
      ]);
      setAllSeminars(seminarsData);
      const confirmedIds = registrationsData
        .filter(r => r.status === 'confirmed')
        .map(r => r.seminarId);
      setRegisteredSeminarIds(confirmedIds);
    } catch (err) {
      console.error('Failed to load initial seminars/registrations:', err);
    }
  }, [user.email]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  const handleNavigate = (page: string, category?: string) => {
    setCurrentPage(page);
    setFilterCategory(category);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewSeminar = (seminar: Seminar) => {
    setSelectedSeminarForDetails(seminar);
  };

  const handleRegisterSeminar = (seminar: Seminar) => {
    setSelectedSeminarForRegister(seminar);
  };

  const handleRegistrationSuccess = (reg: Registration) => {
    setSelectedSeminarForRegister(null);
    setTicketToDisplay(reg);
    loadAllData();
    refreshNotifications();
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Navigation */}
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onViewSeminar={handleViewSeminar}
            onRegisterSeminar={handleRegisterSeminar}
            registeredSeminarIds={registeredSeminarIds}
          />
        )}

        {currentPage === 'explore' && (
          <DiscoveryPage
            initialCategory={filterCategory}
            onViewSeminar={handleViewSeminar}
            onRegisterSeminar={handleRegisterSeminar}
            registeredSeminarIds={registeredSeminarIds}
          />
        )}

        {currentPage === 'registrations' && (
          <MyRegistrationsPage
            onViewTicket={reg => setTicketToDisplay(reg)}
            onExploreSeminars={() => handleNavigate('explore')}
            onRefreshStats={loadAllData}
          />
        )}

        {currentPage === 'assistant' && (
          <AiAssistantPage
            onViewSeminar={handleViewSeminar}
            onRegisterSeminar={handleRegisterSeminar}
            allSeminars={allSeminars}
          />
        )}

        {currentPage === 'organizer' && (
          <OrganizerPage
            onSeminarUpdated={loadAllData}
          />
        )}

        {currentPage === 'admin' && (
          <AdminPage />
        )}

        {currentPage === 'profile' && (
          <ProfilePage />
        )}
      </main>

      {/* Modals */}
      <SeminarDetailModal
        seminar={selectedSeminarForDetails}
        onClose={() => setSelectedSeminarForDetails(null)}
        onRegister={handleRegisterSeminar}
        isRegistered={
          selectedSeminarForDetails
            ? registeredSeminarIds.includes(selectedSeminarForDetails.id)
            : false
        }
      />

      <RegistrationModal
        seminar={selectedSeminarForRegister}
        onClose={() => setSelectedSeminarForRegister(null)}
        onSuccess={handleRegistrationSuccess}
      />

      <RegistrationTicketModal
        registration={ticketToDisplay}
        onClose={() => setTicketToDisplay(null)}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/60 py-8 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-800 dark:text-slate-200">
              Seminar Information Bot
            </span>
            <span>•</span>
            <span>Campus Event Discovery & AI Assistant</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => handleNavigate('assistant')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-indigo-500" />
              <span>AI Assistant</span>
            </button>
            <span>•</span>
            <button
              onClick={() => handleNavigate('explore')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              Browse Seminars
            </button>
            <span>•</span>
            <button
              onClick={() => handleNavigate('profile')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              Privacy & Notice
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <AppContent />
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
