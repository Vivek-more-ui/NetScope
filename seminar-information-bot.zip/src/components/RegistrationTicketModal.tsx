import React from 'react';
import { X, Calendar, Clock, MapPin, Download, CheckCircle2, QrCode, Printer, ShieldCheck } from 'lucide-react';
import { Registration } from '../types/index.js';

interface RegistrationTicketModalProps {
  registration: Registration | null;
  onClose: () => void;
}

export const RegistrationTicketModal: React.FC<RegistrationTicketModalProps> = ({
  registration,
  onClose,
}) => {
  if (!registration) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadIcs = () => {
    window.location.href = `/api/registrations/${registration.id}/ics`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Pass Header */}
        <div className="p-6 bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-800 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center transition-colors text-white"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-5 h-5 text-emerald-300" />
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-200">
              Official University Pass
            </span>
          </div>
          <h3 className="text-xl font-extrabold leading-snug">
            {registration.seminarTitle}
          </h3>
          <p className="text-xs text-indigo-100/90 mt-1">
            Status: Confirmed Registration
          </p>
        </div>

        {/* Pass Cutout Notch simulation */}
        <div className="relative flex items-center justify-between px-4 -my-3">
          <div className="w-6 h-6 rounded-full bg-slate-900/60 backdrop-blur-sm -ml-7" />
          <div className="flex-1 border-t-2 border-dashed border-slate-300 dark:border-slate-700 mx-2" />
          <div className="w-6 h-6 rounded-full bg-slate-900/60 backdrop-blur-sm -mr-7" />
        </div>

        {/* Ticket Details Body */}
        <div className="p-6 space-y-5">
          {/* Ticket Code & QR */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Ticket Reference
              </p>
              <p className="text-lg font-mono font-bold text-indigo-600 dark:text-indigo-400">
                {registration.ticketCode}
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Reg ID: {registration.id}
              </p>
            </div>
            {/* Visual stylized QR code */}
            <div className="w-16 h-16 bg-white dark:bg-slate-900 rounded-xl p-1.5 border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-inner">
              <QrCode className="w-full h-full text-slate-800 dark:text-slate-200" />
            </div>
          </div>

          {/* Attendee Info */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <p className="text-slate-400 font-bold uppercase text-[10px]">Attendee Name</p>
              <p className="font-bold text-slate-800 dark:text-slate-100 text-sm mt-0.5">
                {registration.participantName}
              </p>
            </div>
            <div>
              <p className="text-slate-400 font-bold uppercase text-[10px]">Email Address</p>
              <p className="font-semibold text-slate-700 dark:text-slate-200 truncate mt-0.5">
                {registration.participantEmail}
              </p>
            </div>
            <div>
              <p className="text-slate-400 font-bold uppercase text-[10px]">Institution</p>
              <p className="font-semibold text-slate-700 dark:text-slate-200 truncate mt-0.5">
                {registration.institution}
              </p>
            </div>
            <div>
              <p className="text-slate-400 font-bold uppercase text-[10px]">Department & Year</p>
              <p className="font-semibold text-slate-700 dark:text-slate-200 truncate mt-0.5">
                {registration.department} ({registration.yearOfStudy})
              </p>
            </div>
          </div>

          {/* Event Schedule Info */}
          <div className="space-y-2 p-3.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 text-xs">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span>
                <strong>Date:</strong> {registration.seminarDate}
              </span>
            </div>
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span>
                <strong>Time:</strong> {registration.seminarTime}
              </span>
            </div>
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <MapPin className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span className="truncate">
                <strong>Venue:</strong> {registration.seminarVenue}
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <button
            onClick={handleDownloadIcs}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-xs font-semibold flex items-center justify-center gap-2 shadow-sm"
          >
            <Download className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>Add to Calendar (.ics)</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white transition-colors text-xs font-semibold flex items-center justify-center gap-2 shadow-sm"
          >
            <Printer className="w-4 h-4" />
            <span>Print Pass</span>
          </button>
        </div>
      </div>
    </div>
  );
};
