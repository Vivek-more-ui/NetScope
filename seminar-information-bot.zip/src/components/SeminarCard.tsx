import React from 'react';
import { Calendar, Clock, MapPin, Users, Award, ExternalLink, ArrowRight, ShieldCheck } from 'lucide-react';
import { Seminar } from '../types/index.js';

interface SeminarCardProps {
  seminar: Seminar;
  onViewDetails: (seminar: Seminar) => void;
  onRegister: (seminar: Seminar) => void;
  isRegistered?: boolean;
}

export const SeminarCard: React.FC<SeminarCardProps> = ({
  seminar,
  onViewDetails,
  onRegister,
  isRegistered = false,
}) => {
  const isPast = new Date(seminar.date) < new Date(new Date().toDateString());
  const isDeadlinePassed = new Date(seminar.registrationDeadline) < new Date();
  const isFull = seminar.availableSeats <= 0;
  const isCancelled = seminar.status === 'cancelled';
  const isCompleted = seminar.status === 'completed' || isPast;

  // Level badge styling
  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800';
      case 'Intermediate':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-400 dark:border-indigo-800';
      case 'Advanced':
        return 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-400 dark:border-purple-800';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
    }
  };

  const getFormatBadge = (format: string) => {
    switch (format) {
      case 'In-Person':
        return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800';
      case 'Online':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800';
      default:
        return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800';
    }
  };

  const percentFilled = Math.min(
    100,
    Math.round(((seminar.totalSeats - seminar.availableSeats) / seminar.totalSeats) * 100)
  );

  return (
    <div className="group relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden">
      {/* Top Header Strip with Category & Status */}
      <div className="p-5 pb-3">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
              {seminar.category}
            </span>
            <span className={`text-[11px] font-medium px-2 py-0.5 rounded-md border ${getFormatBadge(seminar.format)}`}>
              {seminar.format}
            </span>
          </div>

          <span className={`text-[11px] font-medium px-2 py-0.5 rounded-md border ${getLevelColor(seminar.level)}`}>
            {seminar.level}
          </span>
        </div>

        {/* Seminar Title */}
        <h3
          onClick={() => onViewDetails(seminar)}
          className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 cursor-pointer transition-colors line-clamp-2 mb-2"
        >
          {seminar.title}
        </h3>

        {/* Short Description */}
        <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
          {seminar.shortDescription}
        </p>

        {/* Speaker Profile Row */}
        <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 mb-4">
          {seminar.speaker.avatarUrl ? (
            <img
              src={seminar.speaker.avatarUrl}
              alt={seminar.speaker.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/20"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold flex items-center justify-center text-sm">
              {seminar.speaker.name.charAt(0)}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
              {seminar.speaker.name}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              {seminar.speaker.designation} • {seminar.speaker.organization}
            </p>
          </div>
        </div>

        {/* Date, Time & Venue metadata */}
        <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span className="font-medium text-slate-800 dark:text-slate-200">
              {new Date(seminar.date).toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span>
              {seminar.startTime} - {seminar.endTime}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span className="truncate">{seminar.venue}</span>
          </div>
        </div>
      </div>

      {/* Bottom Section with Seat Availability & Actions */}
      <div className="p-5 pt-3 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50 mt-auto">
        {/* Seat capacity bar */}
        {!isCancelled && !isCompleted && (
          <div className="mb-3">
            <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3 text-slate-400" />
                {isFull ? (
                  <span className="text-rose-600 dark:text-rose-400 font-semibold">House Full</span>
                ) : (
                  <span>
                    <strong className="text-slate-800 dark:text-slate-200">{seminar.availableSeats}</strong> seats left
                  </span>
                )}
              </span>
              <span>{percentFilled}% full</span>
            </div>
            <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  percentFilled > 85 ? 'bg-amber-500' : 'bg-indigo-600 dark:bg-indigo-500'
                }`}
                style={{ width: `${percentFilled}%` }}
              />
            </div>
          </div>
        )}

        {/* Status flags if cancelled or completed */}
        {isCancelled && (
          <div className="mb-3 px-3 py-1.5 rounded-lg bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 text-xs font-medium border border-rose-200 dark:border-rose-900 flex items-center gap-1.5">
            <span>Event Cancelled</span>
            {seminar.cancellationReason && (
              <span className="truncate font-normal text-rose-600 dark:text-rose-300">
                ({seminar.cancellationReason})
              </span>
            )}
          </div>
        )}

        {isCompleted && !isCancelled && (
          <div className="mb-3 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 text-xs font-medium border border-slate-200 dark:border-slate-700 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-slate-500" />
            <span>Event Completed</span>
          </div>
        )}

        {/* Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onViewDetails(seminar)}
            className="flex-1 px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5"
          >
            <span>View Details</span>
          </button>

          {isRegistered ? (
            <div className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-400 dark:border-emerald-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Registered</span>
            </div>
          ) : isCancelled || isCompleted || isDeadlinePassed || isFull ? (
            <button
              disabled
              className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500 cursor-not-allowed"
            >
              {isCancelled ? 'Cancelled' : isCompleted ? 'Closed' : isFull ? 'Full' : 'Deadline Passed'}
            </button>
          ) : (
            <button
              onClick={() => onRegister(seminar)}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white shadow-sm transition-colors flex items-center justify-center gap-1"
            >
              <span>Register</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
