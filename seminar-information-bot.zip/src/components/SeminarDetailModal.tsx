import React from 'react';
import { X, Calendar, Clock, MapPin, Users, Award, ShieldAlert, CheckCircle2, BookOpen, User, Phone, Mail, ArrowRight, ExternalLink } from 'lucide-react';
import { Seminar } from '../types/index.js';

interface SeminarDetailModalProps {
  seminar: Seminar | null;
  onClose: () => void;
  onRegister: (seminar: Seminar) => void;
  isRegistered?: boolean;
}

export const SeminarDetailModal: React.FC<SeminarDetailModalProps> = ({
  seminar,
  onClose,
  onRegister,
  isRegistered = false,
}) => {
  if (!seminar) return null;

  const isPast = new Date(seminar.date) < new Date(new Date().toDateString());
  const isDeadlinePassed = new Date(seminar.registrationDeadline) < new Date();
  const isFull = seminar.availableSeats <= 0;
  const isCancelled = seminar.status === 'cancelled';
  const isCompleted = seminar.status === 'completed' || isPast;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Hero Banner */}
        <div className={`p-6 sm:p-8 bg-gradient-to-r ${seminar.bannerGradient || 'from-indigo-900 via-indigo-800 to-slate-900'} text-white relative`}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/20 hover:bg-black/40 text-white flex items-center justify-center transition-colors backdrop-blur-md"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="px-3 py-1 text-xs font-bold rounded-full bg-white/20 backdrop-blur-md text-white border border-white/20">
              {seminar.category}
            </span>
            <span className="px-2.5 py-0.5 text-xs font-semibold rounded-md bg-white/10 text-white/90 border border-white/10">
              {seminar.format}
            </span>
            <span className="px-2.5 py-0.5 text-xs font-semibold rounded-md bg-white/10 text-white/90 border border-white/10">
              Level: {seminar.level}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-3 pr-8 leading-tight">
            {seminar.title}
          </h2>

          <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-indigo-100/90 font-medium">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-indigo-300" />
              <span>
                {new Date(seminar.date).toLocaleDateString('en-US', {
                  weekday: 'short',
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-300" />
              <span>{seminar.startTime} - {seminar.endTime}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-indigo-300" />
              <span>{seminar.venue}</span>
            </div>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* Status notices */}
          {isCancelled && (
            <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 text-sm flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">This seminar has been cancelled by the organizer.</p>
                <p className="text-xs mt-1 text-rose-700 dark:text-rose-300">
                  Reason: {seminar.cancellationReason || 'Unforeseen departmental schedule conflict.'}
                </p>
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
              About the Seminar
            </h4>
            <p className="text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              {seminar.description}
            </p>
          </div>

          {/* Learning Objectives */}
          {seminar.learningObjectives && seminar.learningObjectives.length > 0 && (
            <div className="p-5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/50">
              <h4 className="text-sm font-bold text-indigo-950 dark:text-indigo-300 mb-3 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                What You Will Learn
              </h4>
              <ul className="grid sm:grid-cols-2 gap-2.5">
                {seminar.learningObjectives.map((obj, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Detailed Agenda */}
          {seminar.agenda && seminar.agenda.length > 0 && (
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3">
                Event Agenda & Timetable
              </h4>
              <div className="space-y-3 relative border-l-2 border-indigo-200 dark:border-indigo-900 ml-3 pl-4">
                {seminar.agenda.map((item, idx) => (
                  <div key={idx} className="relative">
                    <div className="absolute -left-[23px] top-1.5 w-3 h-3 rounded-full bg-indigo-600 ring-4 ring-white dark:ring-slate-900" />
                    <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                      {item.time}
                    </span>
                    <h5 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                      {item.sessionTitle}
                    </h5>
                    {item.speaker && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        Speaker: {item.speaker}
                      </p>
                    )}
                    {item.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                        {item.description}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Speaker Profile */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3">
              Keynote Speaker
            </h4>
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              {seminar.speaker.avatarUrl ? (
                <img
                  src={seminar.speaker.avatarUrl}
                  alt={seminar.speaker.name}
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-500/30"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-bold text-xl flex items-center justify-center">
                  {seminar.speaker.name.charAt(0)}
                </div>
              )}
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h4 className="text-base font-bold text-slate-900 dark:text-white">
                    {seminar.speaker.name}
                  </h4>
                  {seminar.speaker.linkedin && (
                    <a
                      href={seminar.speaker.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                    >
                      <span>LinkedIn Profile</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                  {seminar.speaker.designation} • {seminar.speaker.organization}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                  {seminar.speaker.bio}
                </p>
              </div>
            </div>
          </div>

          {/* Prerequisites and Eligibility Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Prerequisites & Preparation
              </h5>
              <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                {seminar.prerequisites.map((p, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-indigo-500 font-bold">•</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Eligibility & Target Audience
              </h5>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                {seminar.eligibility}
              </p>
            </div>
          </div>

          {/* Organizer Info */}
          <div className="p-4 rounded-2xl bg-slate-100/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-slate-900 dark:text-white">
                Organized by: {seminar.organizer.name}
              </p>
              <p>{seminar.organizer.department}</p>
            </div>
            <div className="flex items-center gap-3">
              {seminar.organizer.email && (
                <a
                  href={`mailto:${seminar.organizer.email}`}
                  className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>{seminar.organizer.email}</span>
                </a>
              )}
              {seminar.organizer.phone && (
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300">
                  <Phone className="w-3.5 h-3.5" />
                  <span>{seminar.organizer.phone}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-4 mt-auto">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="text-xs">
              <p className="text-slate-500 dark:text-slate-400">Registration Status</p>
              <p className="font-bold text-slate-900 dark:text-white">
                {seminar.availableSeats} of {seminar.totalSeats} seats remaining
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Close
            </button>

            {isRegistered ? (
              <div className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>You are Registered</span>
              </div>
            ) : isCancelled || isCompleted || isDeadlinePassed || isFull ? (
              <button
                disabled
                className="px-5 py-2.5 rounded-xl bg-slate-200 text-slate-400 dark:bg-slate-800 dark:text-slate-500 font-semibold text-sm cursor-not-allowed"
              >
                {isCancelled ? 'Cancelled' : isCompleted ? 'Completed' : isFull ? 'Event Full' : 'Registration Closed'}
              </button>
            ) : (
              <button
                onClick={() => {
                  onClose();
                  onRegister(seminar);
                }}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm shadow-md transition-colors flex items-center gap-2"
              >
                <span>Register for this Seminar</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
