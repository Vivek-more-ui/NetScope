import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types/index.js';

interface AuthContextType {
  user: UserProfile;
  switchRole: (role: UserRole) => void;
  updateProfile: (updated: Partial<UserProfile>) => void;
  availableRoles: { role: UserRole; label: string; desc: string; defaultUser: UserProfile }[];
}

const PRESET_USERS: Record<UserRole, UserProfile> = {
  student: {
    id: 'usr-student-1',
    name: 'Satyam Sharma',
    email: 'satyam.gdgsnjb@gmail.com',
    role: 'student',
    institution: 'SNJB College of Engineering',
    department: 'Computer Science & Engineering',
    yearOfStudy: '3rd Year',
    phone: '+91 98765 43210',
    interests: ['Artificial Intelligence', 'Cybersecurity', 'Web Development', 'Career Development'],
  },
  organizer: {
    id: 'usr-organizer-1',
    name: 'Dr. Aarav Deshmukh',
    email: 'aarav.deshmukh@college.edu',
    role: 'organizer',
    institution: 'SNJB College of Engineering',
    department: 'Department of Computer Science & Engineering',
    phone: '+91 98230 45671',
    interests: ['Artificial Intelligence', 'Machine Learning', 'Research and Innovation'],
  },
  admin: {
    id: 'usr-admin-1',
    name: 'Prof. S. R. Kulkarni',
    email: 'admin.academic@college.edu',
    role: 'admin',
    institution: 'SNJB College of Engineering',
    department: 'Dean of Academic Affairs',
    phone: '+91 94220 12345',
    interests: ['College Administration', 'Accreditation', 'Curriculum Innovation'],
  },
  speaker: {
    id: 'usr-speaker-1',
    name: 'Priya Sharma',
    email: 'priya.sharma@vertexlabs.ai',
    role: 'speaker',
    institution: 'Vertex AI Labs / Ex-Google',
    department: 'AI Research Division',
    phone: '+1 415 555 0192',
    interests: ['Generative AI', 'Large Language Models', 'Distributed Systems'],
  },
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('seminar_bot_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return PRESET_USERS.student;
  });

  useEffect(() => {
    localStorage.setItem('seminar_bot_user', JSON.stringify(user));
  }, [user]);

  const switchRole = (role: UserRole) => {
    setUser(PRESET_USERS[role]);
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updated }));
  };

  const availableRoles: { role: UserRole; label: string; desc: string; defaultUser: UserProfile }[] = [
    {
      role: 'student',
      label: 'College Student',
      desc: 'Discover seminars, register, get tickets, and query AI assistant',
      defaultUser: PRESET_USERS.student,
    },
    {
      role: 'organizer',
      label: 'Faculty Organizer',
      desc: 'Create, publish, edit seminars and export participant CSV lists',
      defaultUser: PRESET_USERS.organizer,
    },
    {
      role: 'admin',
      label: 'College Administrator',
      desc: 'Campus-wide metrics, approve events, broadcast announcements',
      defaultUser: PRESET_USERS.admin,
    },
    {
      role: 'speaker',
      label: 'Guest Speaker',
      desc: 'View assigned speaking schedules, attendee counts, and agendas',
      defaultUser: PRESET_USERS.speaker,
    },
  ];

  return (
    <AuthContext.Provider value={{ user, switchRole, updateProfile, availableRoles }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
