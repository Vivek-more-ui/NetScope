import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  CheckCircle,
  XCircle,
  TrendingUp,
  BellPlus,
  Users,
  Calendar,
  Layers,
  Sparkles,
  Award,
  AlertCircle,
  Pin,
} from 'lucide-react';
import { Seminar, Announcement, DashboardStats } from '../types/index.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';

export const AdminPage: React.FC = () => {
  const { user, switchRole } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [seminars, setSeminars] = useState<Seminar[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  // Announcement Form State
  const [showAnnounceModal, setShowAnnounceModal] = useState(false);
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annPriority, setAnnPriority] = useState<'normal' | 'high' | 'urgent'>('normal');
  const [annPinned, setAnnPinned] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [statsData, seminarsData, announcementsData] = await Promise.all([
        api.getStats(),
        api.getSeminars(),
        api.getAnnouncements(),
      ]);
      setStats(statsData);
      setSeminars(seminarsData);
      setAnnouncements(announcementsData);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annContent.trim()) return;

    try {
      await api.createAnnouncement({
        title: annTitle.trim(),
        content: annContent.trim(),
        priority: annPriority,
        pinned: annPinned,
      });
      setShowAnnounceModal(false);
      setAnnTitle('');
      setAnnContent('');
      setAnnPriority('normal');
      setAnnPinned(false);
      await loadData();
    } catch (err) {
      console.error('Failed to create announcement:', err);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            University Oversight
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Administrator Desk & Analytics
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Campus-wide seminar approvals, official broadcast announcements, and engagement metrics.
          </p>
        </div>

        <button
          onClick={() => setShowAnnounceModal(true)}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm flex items-center gap-2 self-start sm:self-auto cursor-pointer"
        >
          <BellPlus className="w-4 h-4" />
          <span>Broadcast Announcement</span>
        </button>
      </div>

      {/* Role Reminder Banner if testing as student */}
      {user.role !== 'admin' && (
        <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 text-indigo-900 dark:text-indigo-200 text-xs flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-indigo-600" />
            <span>
              You are simulating in <strong>{user.role}</strong> mode. Switch to Administrator to test top-level approval workflows:
            </span>
          </div>
          <button
            onClick={() => switchRole('admin')}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shrink-0 cursor-pointer"
          >
            Switch to Administrator
          </button>
        </div>
      )}

      {/* Metrics Row */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Total Published Seminars</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {seminars.filter(s => s.status === 'published').length}
            </p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
              Active across all departments
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Total Event Registrations</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {stats.totalRegistrationsCount}
            </p>
            <p className="text-[11px] text-indigo-600 dark:text-indigo-400 mt-1">
              Confirmed student attendance
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Upcoming Seminars</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {stats.upcomingSeminars}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">In next 60 days</p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Completed Archives</p>
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              {stats.completedSeminars}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">Archived session notes</p>
          </div>
        </div>
      )}

      {/* Broadcast Announcements Management */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BellPlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              Campus Broadcast Announcements ({announcements.length})
            </h3>
          </div>
          <button
            onClick={() => setShowAnnounceModal(true)}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            + Post Announcement
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {announcements.map(ann => (
            <div
              key={ann.id}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 text-xs space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  {ann.pinned && <Pin className="w-3.5 h-3.5 text-indigo-600" />}
                  {ann.title}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    ann.priority === 'high'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  {ann.priority.toUpperCase()}
                </span>
              </div>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                {ann.content}
              </p>
              <p className="text-[10px] text-slate-400 pt-2 border-t border-slate-200 dark:border-slate-700">
                Posted by {ann.author} ({ann.department}) on {new Date(ann.createdAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Seminar Moderation & Approval Queue */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            All Campus Seminars & Verification Status
          </h3>
          <span className="text-xs text-slate-400">Strictly verified curriculum</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Title</th>
                <th className="py-3.5 px-4">Organizer</th>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Registered</th>
                <th className="py-3.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {seminars.map(s => (
                <tr key={s.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="py-3.5 px-4">
                    <p className="font-bold text-slate-900 dark:text-white">{s.title}</p>
                    <p className="text-[10px] text-slate-400">{s.category} • {s.level}</p>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-semibold">{s.organizer.name}</p>
                    <p className="text-[10px] text-slate-400">{s.organizer.department}</p>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    {s.date}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap font-bold">
                    {s.registeredCount} / {s.totalSeats}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                        s.status === 'published'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                          : s.status === 'cancelled'
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Broadcast Modal */}
      {showAnnounceModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BellPlus className="w-4 h-4 text-indigo-600" />
              <span>Broadcast Campus Announcement</span>
            </h3>
            <p className="text-xs text-slate-500">
              This announcement will be pushed to the college dashboard and broadcast to student notification feeds.
            </p>

            <form onSubmit={handleCreateAnnouncement} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Announcement Title *
                </label>
                <input
                  type="text"
                  required
                  value={annTitle}
                  onChange={e => setAnnTitle(e.target.value)}
                  placeholder="e.g. Venue Change for Nov 4 IoT Seminar"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Announcement Content *
                </label>
                <textarea
                  required
                  rows={4}
                  value={annContent}
                  onChange={e => setAnnContent(e.target.value)}
                  placeholder="Detailed campus notification..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={annPriority}
                    onChange={e => setAnnPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="normal">Normal</option>
                    <option value="high">High Priority</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={annPinned}
                      onChange={e => setAnnPinned(e.target.checked)}
                      className="rounded text-indigo-600"
                    />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      Pin to Top of Dashboard
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAnnounceModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
                >
                  Broadcast to Campus
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
