import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Calendar,
  X,
  Users,
  CheckCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Seminar, SeminarCategory } from '../types/index.js';
import { api } from '../services/api.js';
import { SeminarCard } from '../components/SeminarCard.js';

interface DiscoveryPageProps {
  initialCategory?: string;
  onViewSeminar: (seminar: Seminar) => void;
  onRegisterSeminar: (seminar: Seminar) => void;
  registeredSeminarIds: string[];
}

export const DiscoveryPage: React.FC<DiscoveryPageProps> = ({
  initialCategory,
  onViewSeminar,
  onRegisterSeminar,
  registeredSeminarIds,
}) => {
  const [seminars, setSeminars] = useState<Seminar[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'all');
  const [selectedFormat, setSelectedFormat] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [onlyOpenSeats, setOnlyOpenSeats] = useState(false);
  const [sortBy, setSortBy] = useState<'date-asc' | 'seats-desc' | 'popular-desc'>('date-asc');

  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
  }, [initialCategory]);

  useEffect(() => {
    async function loadSeminars() {
      try {
        setLoading(true);
        const data = await api.getSeminars();
        setSeminars(data);
      } catch (err) {
        console.error('Failed to load seminars:', err);
      } finally {
        setLoading(false);
      }
    }
    loadSeminars();
  }, []);

  const categories: SeminarCategory[] = [
    'Artificial Intelligence',
    'Machine Learning',
    'Data Science',
    'Cloud Computing',
    'Cybersecurity',
    'Web Development',
    'Mobile App Development',
    'Internet of Things',
    'Entrepreneurship',
    'Career Development',
    'Research and Innovation',
  ];

  const filteredSeminars = useMemo(() => {
    return seminars
      .filter(s => {
        // Only show published or completed in explorer, unless searching
        if (s.status === 'draft') return false;

        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchesTitle = s.title.toLowerCase().includes(q);
          const matchesSpeaker = s.speaker.name.toLowerCase().includes(q);
          const matchesCategory = s.category.toLowerCase().includes(q);
          const matchesDesc = s.shortDescription.toLowerCase().includes(q);
          const matchesTags = s.tags.some(t => t.toLowerCase().includes(q));
          if (!matchesTitle && !matchesSpeaker && !matchesCategory && !matchesDesc && !matchesTags) {
            return false;
          }
        }

        // Category
        if (selectedCategory !== 'all' && s.category.toLowerCase() !== selectedCategory.toLowerCase()) {
          return false;
        }

        // Format
        if (selectedFormat !== 'all' && s.format.toLowerCase() !== selectedFormat.toLowerCase()) {
          return false;
        }

        // Level
        if (selectedLevel !== 'all' && s.level.toLowerCase() !== selectedLevel.toLowerCase()) {
          return false;
        }

        // Only open seats
        if (onlyOpenSeats && (s.availableSeats <= 0 || s.status !== 'published')) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'seats-desc') {
          return b.availableSeats - a.availableSeats;
        }
        if (sortBy === 'popular-desc') {
          return b.registeredCount - a.registeredCount;
        }
        // Default: date-asc
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });
  }, [seminars, searchQuery, selectedCategory, selectedFormat, selectedLevel, onlyOpenSeats, sortBy]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedFormat('all');
    setSelectedLevel('all');
    setOnlyOpenSeats(false);
    setSortBy('date-asc');
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedCategory !== 'all' ||
    selectedFormat !== 'all' ||
    selectedLevel !== 'all' ||
    onlyOpenSeats;

  return (
    <div className="space-y-8 pb-16">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            Directory & Catalog
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Explore College Seminars
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
          Discover verified seminars, workshops, and technical talks organized by university departments and industry professionals.
        </p>
      </div>

      {/* Search Bar & Primary Controls */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by topic, speaker name, technology (e.g. LLM, Zero Trust, React)..."
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort By Selector */}
          <div className="sm:w-56">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="date-asc">Date: Soonest First</option>
              <option value="popular-desc">Most Popular (Registrations)</option>
              <option value="seats-desc">Most Open Seats</option>
            </select>
          </div>
        </div>

        {/* Filter Badges & Dropdowns */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500 dark:text-slate-400">Category:</span>
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Categories ({seminars.length})</option>
              {categories.map(c => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Format Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500 dark:text-slate-400">Format:</span>
            <select
              value={selectedFormat}
              onChange={e => setSelectedFormat(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Formats</option>
              <option value="In-Person">In-Person</option>
              <option value="Online">Online</option>
              <option value="Hybrid">Hybrid</option>
            </select>
          </div>

          {/* Level Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500 dark:text-slate-400">Level:</span>
            <select
              value={selectedLevel}
              onChange={e => setSelectedLevel(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Levels</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Open Seats Toggle */}
          <label className="flex items-center gap-2 cursor-pointer select-none px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors">
            <input
              type="checkbox"
              checked={onlyOpenSeats}
              onChange={e => setOnlyOpenSeats(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span className="font-medium text-slate-700 dark:text-slate-300">
              Open Seats Only
            </span>
          </label>

          {/* Clear Filters Button */}
          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              className="ml-auto text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Results Header Count */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>
          Showing <strong className="text-slate-900 dark:text-white">{filteredSeminars.length}</strong> verified seminars
        </span>
        {hasActiveFilters && (
          <span className="italic">Filtered results</span>
        )}
      </div>

      {/* Seminars Grid */}
      {loading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div
              key={i}
              className="h-80 rounded-2xl bg-slate-100 dark:bg-slate-800 animate-pulse border border-slate-200 dark:border-slate-700"
            />
          ))}
        </div>
      ) : filteredSeminars.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            No seminars match your selected filters
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Try adjusting your search terms, choosing "All Categories", or unchecking the "Open Seats Only" filter.
          </p>
          <button
            onClick={resetFilters}
            className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors inline-block mt-2 cursor-pointer"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSeminars.map(sem => (
            <SeminarCard
              key={sem.id}
              seminar={sem}
              onViewDetails={onViewSeminar}
              onRegister={onRegisterSeminar}
              isRegistered={registeredSeminarIds.includes(sem.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
