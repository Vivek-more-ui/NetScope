import React, { useEffect, useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Calendar,
  Users,
  CheckCircle,
  Clock,
  Award,
  Search,
  BellRing,
  BookOpen,
  Compass,
  Cpu,
  Shield,
  Zap,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { Seminar, DashboardStats, Announcement } from '../types/index.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { SeminarCard } from '../components/SeminarCard.js';

interface HomePageProps {
  onNavigate: (page: string, filterCategory?: string) => void;
  onViewSeminar: (seminar: Seminar) => void;
  onRegisterSeminar: (seminar: Seminar) => void;
  registeredSeminarIds: string[];
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onViewSeminar,
  onRegisterSeminar,
  registeredSeminarIds,
}) => {
  const { user } = useAuth();

  const [stats, setStats] = useState<DashboardStats>({
    upcomingSeminars: 0,
    availableRegistrations: 0,
    myRegisteredSeminars: 0,
    completedSeminars: 0,
    totalRegistrationsCount: 0,
  });
  const [featuredSeminars, setFeaturedSeminars] = useState<Seminar[]>([]);
  const [upcomingSeminars, setUpcomingSeminars] = useState<Seminar[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadHomeData() {
      try {
        setLoading(true);
        const [statsData, seminarsData, announcementsData] = await Promise.all([
          api.getStats(user.email),
          api.getSeminars({ status: 'published' }),
          api.getAnnouncements(),
        ]);

        setStats(statsData);
        setAnnouncements(announcementsData);

        const now = new Date().toISOString().slice(0, 10);
        const upcoming = seminarsData.filter(s => s.date >= now);
        setUpcomingSeminars(upcoming.slice(0, 6));

        const featured = seminarsData.filter(s => s.isFeatured && s.date >= now);
        setFeaturedSeminars(featured.length > 0 ? featured : upcoming.slice(0, 3));
      } catch (err) {
        console.error('Failed to load homepage data:', err);
      } finally {
        setLoading(false);
      }
    }

    loadHomeData();
  }, [user.email]);

  const categories = [
    { name: 'Artificial Intelligence', icon: Cpu, color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 dark:text-indigo-400' },
    { name: 'Cybersecurity', icon: Shield, color: 'text-cyan-600 bg-cyan-50 dark:bg-cyan-950/50 dark:text-cyan-400' },
    { name: 'Web Development', icon: Zap, color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/50 dark:text-amber-400' },
    { name: 'Entrepreneurship', icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 dark:text-emerald-400' },
    { name: 'Data Science', icon: Compass, color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/50 dark:text-blue-400' },
    { name: 'Career Development', icon: BookOpen, color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/50 dark:text-purple-400' },
  ];

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-white p-8 sm:p-12 lg:p-16 border border-slate-800 shadow-xl">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI-Powered Campus Seminar Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight text-white mb-6">
            Discover. Learn. Connect.
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-8 max-w-2xl font-normal">
            Your smart assistant for discovering seminars, exploring new technologies, and participating in learning opportunities.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => onNavigate('explore')}
              className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Explore Seminars</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('assistant')}
              className="px-6 py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-sm backdrop-blur-md border border-white/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Ask AI Assistant</span>
            </button>
          </div>
        </div>
      </section>

      {/* Verified Dashboard Statistics */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            Platform Activity & Real Data
          </h2>
          <span className="text-xs text-slate-500">Live verified database counts</span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Upcoming Seminars
              </span>
              <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <Calendar className="w-4 h-4" />
              </div>
            </div>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.upcomingSeminars}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Scheduled & verified</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Available Registrations
              </span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.availableRegistrations}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Events with open seats</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                My Registered Seminars
              </span>
              <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <CheckCircle className="w-4 h-4" />
              </div>
            </div>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.myRegisteredSeminars}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Confirmed student passes</p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Completed Seminars
              </span>
              <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.completedSeminars}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Archived session notes</p>
          </div>
        </div>
      </section>

      {/* Important Announcements Banner */}
      {announcements.length > 0 && (
        <section className="p-6 rounded-3xl bg-slate-100/80 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 mb-4">
            <BellRing className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              Official Campus Announcements
            </h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {announcements.map(ann => (
              <div
                key={ann.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/70 dark:border-slate-700/80"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    {ann.title}
                  </span>
                  {ann.priority === 'high' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                      High Priority
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {ann.content}
                </p>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-100 dark:border-slate-700/60">
                  <span>{ann.author} • {ann.department}</span>
                  <span>{new Date(ann.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Popular Topics / Category Quick Filter */}
      <section>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Popular Topics
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Browse seminars by discipline or technology domain
            </p>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>All Categories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {categories.map(c => {
            const Icon = c.icon;
            return (
              <button
                key={c.name}
                onClick={() => onNavigate('explore', c.name)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 hover:shadow-sm transition-all text-left flex flex-col justify-between group cursor-pointer"
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${c.color} group-hover:scale-105 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-1">
                    {c.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">Browse events</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Featured Seminars */}
      {featuredSeminars.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  Featured Masterclasses
                </h2>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Flagship sessions led by industry pioneers and research faculty
              </p>
            </div>
            <button
              onClick={() => onNavigate('explore')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredSeminars.map(sem => (
              <SeminarCard
                key={sem.id}
                seminar={sem}
                onViewDetails={onViewSeminar}
                onRegister={onRegisterSeminar}
                isRegistered={registeredSeminarIds.includes(sem.id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming Seminars */}
      <section>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              Upcoming Events
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Verified sessions scheduled for October & November 2026
            </p>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>See Calendar Schedule</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {upcomingSeminars.length === 0 && !loading ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <Calendar className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No upcoming seminars available
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              Check back soon or explore past archives.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingSeminars.map(sem => (
              <SeminarCard
                key={sem.id}
                seminar={sem}
                onViewDetails={onViewSeminar}
                onRegister={onRegisterSeminar}
                isRegistered={registeredSeminarIds.includes(sem.id)}
              />
            ))}
          </div>
        )}
      </section>

      {/* AI Assistant Quick Callout */}
      <section className="p-8 rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-xl text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            <span>Multilingual Assistant (English, हिन्दी, मराठी)</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold">
            Unsure which seminar fits your career roadmap?
          </h3>
          <p className="text-xs sm:text-sm text-indigo-100/90 leading-relaxed">
            Ask our AI bot about prerequisites, technical concepts, speaker bios, and verified schedules. Grounded strictly in college records.
          </p>
        </div>
        <button
          onClick={() => onNavigate('assistant')}
          className="px-6 py-3.5 rounded-2xl bg-white text-indigo-900 font-bold text-xs sm:text-sm hover:bg-indigo-50 shadow-md transition-all shrink-0 cursor-pointer"
        >
          Open Seminar Assistant
        </button>
      </section>
    </div>
  );
};
