import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  QrCode,
  Download,
  XCircle,
  CheckCircle,
  ExternalLink,
  Search,
  Filter,
  AlertCircle,
  Ticket,
} from 'lucide-react';
import { Registration, Seminar } from '../types/index.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';

interface MyRegistrationsPageProps {
  onViewTicket: (reg: Registration) => void;
  onExploreSeminars: () => void;
  onRefreshStats: () => void;
}

export const MyRegistrationsPage: React.FC<MyRegistrationsPageProps> = ({
  onViewTicket,
  onExploreSeminars,
  onRefreshStats,
}) => {
  const { user } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterTab, setFilterTab] = useState<'upcoming' | 'past' | 'cancelled' | 'all'>('upcoming');
  const [searchQuery, setSearchQuery] = useState('');
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadRegistrations = async () => {
    try {
      setLoading(true);
      const data = await api.getRegistrations({ userEmail: user.email });
      setRegistrations(data);
    } catch (err) {
      console.error('Failed to load user registrations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRegistrations();
  }, [user.email]);

  const handleCancelRegistration = async (reg: Registration) => {
    if (!window.confirm(`Are you sure you want to cancel your registration for "${reg.seminarTitle}"? Your seat will be released for other students.`)) {
      return;
    }

    try {
      setCancellingId(reg.id);
      const msg = await api.cancelRegistration(reg.id, user.email);
      setActionMessage({ type: 'success', text: msg });
      await loadRegistrations();
      onRefreshStats();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err.message || 'Failed to cancel registration.' });
    } finally {
      setCancellingId(null);
    }
  };

  const now = new Date().toISOString().slice(0, 10);

  const filtered = registrations.filter(r => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      if (!r.seminarTitle.toLowerCase().includes(q) && !r.ticketCode.toLowerCase().includes(q)) {
        return false;
      }
    }

    if (filterTab === 'upcoming') {
      return r.status === 'confirmed' && r.seminarDate >= now;
    }
    if (filterTab === 'past') {
      return r.status === 'attended' || (r.status === 'confirmed' && r.seminarDate < now);
    }
    if (filterTab === 'cancelled') {
      return r.status === 'cancelled';
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            Personal Dashboard
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            My Registered Seminars
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Access your university event passes, schedule calendar invites, and manage participation.
          </p>
        </div>

        <button
          onClick={onExploreSeminars}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm self-start sm:self-auto cursor-pointer"
        >
          Explore More Seminars
        </button>
      </div>

      {actionMessage && (
        <div
          className={`p-4 rounded-2xl text-xs font-medium border flex items-center justify-between ${
            actionMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900'
              : 'bg-rose-50 text-rose-800 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-900'
          }`}
        >
          <span>{actionMessage.text}</span>
          <button onClick={() => setActionMessage(null)} className="font-bold underline ml-2">
            Dismiss
          </button>
        </div>
      )}

      {/* Tabs and Search Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setFilterTab('upcoming')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              filterTab === 'upcoming'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setFilterTab('past')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              filterTab === 'past'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Past & Attended
          </button>
          <button
            onClick={() => setFilterTab('cancelled')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              filterTab === 'cancelled'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Cancelled
          </button>
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              filterTab === 'all'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            All ({registrations.length})
          </button>
        </div>

        <div className="relative sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search registrations..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Registration Cards List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 rounded-2xl bg-slate-100 dark:bg-slate-800 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <Ticket className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            No registrations found in this category
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Explore our verified seminar catalog and reserve your seat with instant digital pass generation.
          </p>
          <button
            onClick={onExploreSeminars}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors inline-block mt-2 cursor-pointer"
          >
            Find Seminars to Attend
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(reg => {
            const isConfirmed = reg.status === 'confirmed';
            const isCancelled = reg.status === 'cancelled';
            const isAttended = reg.status === 'attended';

            return (
              <div
                key={reg.id}
                className={`p-6 rounded-3xl border transition-all duration-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 ${
                  isCancelled
                    ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-75'
                    : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 shadow-xs hover:shadow-md'
                }`}
              >
                {/* Left: Info */}
                <div className="space-y-3 max-w-2xl">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                      {reg.ticketCode}
                    </span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                      Format: {reg.seminarFormat}
                    </span>
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                        isConfirmed
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                          : isAttended
                          ? 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800'
                          : 'bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800'
                      }`}
                    >
                      {reg.status.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug">
                    {reg.seminarTitle}
                  </h3>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 dark:text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      <strong className="text-slate-800 dark:text-slate-200">{reg.seminarDate}</strong>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      <span>{reg.seminarTime}</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      <span className="truncate max-w-xs">{reg.seminarVenue}</span>
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 dark:text-slate-500">
                    Registered on {new Date(reg.registeredAt).toLocaleDateString()} for {reg.participantName} ({reg.department}, {reg.yearOfStudy})
                  </p>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2.5 w-full md:w-auto justify-end border-t md:border-t-0 pt-4 md:pt-0 border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => onViewTicket(reg)}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <QrCode className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>View Pass</span>
                  </button>

                  {isConfirmed && (
                    <a
                      href={`/api/registrations/${reg.id}/ics`}
                      className="px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors flex items-center gap-1.5"
                      title="Add to Google / Apple Calendar"
                    >
                      <Download className="w-4 h-4 text-slate-500" />
                      <span className="hidden sm:inline">.ICS</span>
                    </a>
                  )}

                  {isConfirmed && (
                    <button
                      onClick={() => handleCancelRegistration(reg)}
                      disabled={cancellingId === reg.id}
                      className="px-3.5 py-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    >
                      {cancellingId === reg.id ? 'Cancelling...' : 'Cancel'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
