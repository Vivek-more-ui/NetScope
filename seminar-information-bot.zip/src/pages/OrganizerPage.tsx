import React, { useState, useEffect } from 'react';
import {
  Plus,
  Edit,
  Trash2,
  Users,
  Download,
  AlertTriangle,
  CheckCircle,
  Eye,
  Calendar,
  Clock,
  MapPin,
  X,
  Loader2,
  FileSpreadsheet,
  ShieldAlert,
} from 'lucide-react';
import { Seminar, Registration, SeminarCategory, SeminarFormat, SeminarLevel } from '../types/index.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';

interface OrganizerPageProps {
  onSeminarUpdated: () => void;
}

export const OrganizerPage: React.FC<OrganizerPageProps> = ({ onSeminarUpdated }) => {
  const { user, switchRole } = useAuth();
  const [seminars, setSeminars] = useState<Seminar[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingSeminar, setEditingSeminar] = useState<Seminar | null>(null);
  const [selectedSeminarForAttendees, setSelectedSeminarForAttendees] = useState<Seminar | null>(null);
  const [attendees, setAttendees] = useState<Registration[]>([]);
  const [attendeesLoading, setAttendeesLoading] = useState(false);
  const [attendeeSearch, setAttendeeSearch] = useState('');

  // Cancellation modal
  const [cancellingSeminar, setCancellingSeminar] = useState<Seminar | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');
  const [cancellationSubmitting, setCancellationSubmitting] = useState(false);

  // Seminar Form State
  const [formData, setFormData] = useState({
    title: '',
    category: 'Artificial Intelligence' as SeminarCategory,
    format: 'In-Person' as SeminarFormat,
    level: 'Intermediate' as SeminarLevel,
    date: '2026-11-18',
    startTime: '10:00 AM',
    endTime: '01:00 PM',
    venue: 'Sir C.V. Raman Auditorium, Main Block',
    meetingLink: '',
    totalSeats: 120,
    registrationDeadline: '2026-11-17T20:00:00Z',
    shortDescription: '',
    description: '',
    learningObjectives: 'Hands-on system building\nDeep dive into architectures\nEvaluation and best practices',
    prerequisites: 'Basic Python programming\nFoundational math knowledge',
    eligibility: 'Open to all Engineering & Tech Students',
    speakerName: 'Dr. Ramesh Sharma',
    speakerDesignation: 'Principal Researcher',
    speakerOrg: 'AI Research Institute',
    speakerBio: 'Expert in distributed machine learning and cognitive systems with over a decade of industry leadership.',
    status: 'published' as 'published' | 'draft',
  });

  const loadSeminars = async () => {
    try {
      setLoading(true);
      const data = await api.getSeminars();
      setSeminars(data);
    } catch (err) {
      console.error('Failed to load seminars:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSeminars();
  }, []);

  const openAttendees = async (seminar: Seminar) => {
    setSelectedSeminarForAttendees(seminar);
    try {
      setAttendeesLoading(true);
      const list = await api.getRegistrations({ seminarId: seminar.id });
      setAttendees(list);
    } catch (err) {
      console.error('Failed to load attendees:', err);
    } finally {
      setAttendeesLoading(false);
    }
  };

  const handleTogglePublish = async (seminar: Seminar) => {
    const nextStatus = seminar.status === 'published' ? 'draft' : 'published';
    try {
      await api.updateSeminar(seminar.id, { status: nextStatus });
      await loadSeminars();
      onSeminarUpdated();
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleCancelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cancellingSeminar) return;

    try {
      setCancellationSubmitting(true);
      await api.cancelSeminar(cancellingSeminar.id, cancellationReason);
      setCancellingSeminar(null);
      setCancellationReason('');
      await loadSeminars();
      onSeminarUpdated();
    } catch (err) {
      console.error('Failed to cancel seminar:', err);
    } finally {
      setCancellationSubmitting(false);
    }
  };

  const handleSaveSeminar = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      title: formData.title,
      slug: formData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      category: formData.category,
      format: formData.format,
      level: formData.level,
      date: formData.date,
      startTime: formData.startTime,
      endTime: formData.endTime,
      venue: formData.venue,
      meetingLink: formData.meetingLink,
      totalSeats: Number(formData.totalSeats),
      registrationDeadline: formData.registrationDeadline,
      shortDescription: formData.shortDescription,
      description: formData.description,
      learningObjectives: formData.learningObjectives.split('\n').filter(Boolean),
      prerequisites: formData.prerequisites.split('\n').filter(Boolean),
      eligibility: formData.eligibility,
      agenda: [
        { time: `${formData.startTime} - 11:00 AM`, sessionTitle: 'Foundations & Keynote', speaker: formData.speakerName },
        { time: `11:00 AM - 12:30 PM`, sessionTitle: 'Core Methodology & Demonstration', speaker: formData.speakerName },
        { time: `12:30 PM - ${formData.endTime}`, sessionTitle: 'Interactive Q&A and Next Steps', speaker: formData.speakerName },
      ],
      speaker: {
        name: formData.speakerName,
        designation: formData.speakerDesignation,
        organization: formData.speakerOrg,
        bio: formData.speakerBio,
      },
      organizer: {
        id: user.id,
        name: user.name,
        department: user.department,
        email: user.email,
        phone: user.phone,
      },
      status: formData.status,
      tags: [formData.category, formData.format],
      bannerGradient: 'from-indigo-600 via-purple-600 to-slate-900',
    };

    try {
      if (editingSeminar) {
        await api.updateSeminar(editingSeminar.id, payload);
      } else {
        await api.createSeminar(payload);
      }
      setShowCreateModal(false);
      setEditingSeminar(null);
      await loadSeminars();
      onSeminarUpdated();
    } catch (err) {
      console.error('Failed to save seminar:', err);
    }
  };

  const openEdit = (sem: Seminar) => {
    setEditingSeminar(sem);
    setFormData({
      title: sem.title,
      category: sem.category,
      format: sem.format,
      level: sem.level,
      date: sem.date,
      startTime: sem.startTime,
      endTime: sem.endTime,
      venue: sem.venue,
      meetingLink: sem.meetingLink || '',
      totalSeats: sem.totalSeats,
      registrationDeadline: sem.registrationDeadline,
      shortDescription: sem.shortDescription,
      description: sem.description,
      learningObjectives: sem.learningObjectives.join('\n'),
      prerequisites: sem.prerequisites.join('\n'),
      eligibility: sem.eligibility,
      speakerName: sem.speaker.name,
      speakerDesignation: sem.speaker.designation,
      speakerOrg: sem.speaker.organization,
      speakerBio: sem.speaker.bio,
      status: sem.status as any,
    });
    setShowCreateModal(true);
  };

  const categories: SeminarCategory[] = [
    'Artificial Intelligence',
    'Machine Learning',
    'Data Science',
    'Cloud Computing',
    'Cybersecurity',
    'Web Development',
    'Mobile App Development',
    'Internet of Things',
    'Entrepreneurship',
    'Career Development',
    'Research and Innovation',
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            Faculty & Organizer Desk
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Seminar Management Portal
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Publish upcoming academic events, inspect participant rosters, and export attendee lists.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingSeminar(null);
            setShowCreateModal(true);
          }}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm flex items-center gap-2 self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Seminar</span>
        </button>
      </div>

      {/* Role Reminder Banner if testing as student */}
      {user.role !== 'organizer' && user.role !== 'admin' && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-200 text-xs flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
            <span>
              You are currently viewing in <strong>{user.role}</strong> mode. To simulate official organizer powers:
            </span>
          </div>
          <button
            onClick={() => switchRole('organizer')}
            className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shrink-0 cursor-pointer"
          >
            Switch to Faculty Organizer
          </button>
        </div>
      )}

      {/* Seminars Management Table / Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            All Managed Events ({seminars.length})
          </h3>
          <span className="text-xs text-slate-400">Total capacity management</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Event Title & Category</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4">Format / Venue</th>
                <th className="py-3.5 px-4">Registrations</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {seminars.map(sem => {
                const isPublished = sem.status === 'published';
                const isCancelled = sem.status === 'cancelled';

                return (
                  <tr key={sem.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-4 px-4 max-w-xs">
                      <p className="font-bold text-slate-900 dark:text-white truncate">
                        {sem.title}
                      </p>
                      <span className="text-[10px] text-slate-400">
                        {sem.category} • Speaker: {sem.speaker.name}
                      </span>
                    </td>

                    <td className="py-4 px-4 whitespace-nowrap">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{sem.date}</p>
                      <p className="text-[11px] text-slate-400">{sem.startTime}</p>
                    </td>

                    <td className="py-4 px-4 max-w-[160px] truncate">
                      <p className="font-medium">{sem.format}</p>
                      <p className="text-[11px] text-slate-400 truncate">{sem.venue}</p>
                    </td>

                    <td className="py-4 px-4 whitespace-nowrap">
                      <button
                        onClick={() => openAttendees(sem)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold hover:underline flex items-center gap-1.5"
                      >
                        <Users className="w-3.5 h-3.5" />
                        <span>{sem.registeredCount} / {sem.totalSeats}</span>
                      </button>
                    </td>

                    <td className="py-4 px-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                          isPublished
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-400'
                            : isCancelled
                            ? 'bg-rose-50 text-rose-700 border border-rose-200 dark:bg-rose-950/50 dark:text-rose-400'
                            : 'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/50 dark:text-amber-400'
                        }`}
                      >
                        {sem.status}
                      </span>
                    </td>

                    <td className="py-4 px-4 text-right whitespace-nowrap space-x-1.5">
                      <button
                        onClick={() => openEdit(sem)}
                        className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                        title="Edit Seminar"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleTogglePublish(sem)}
                        className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-semibold"
                        title="Toggle Draft/Published"
                      >
                        {isPublished ? 'Unpublish' : 'Publish'}
                      </button>

                      {!isCancelled && (
                        <button
                          onClick={() => {
                            setCancellingSeminar(sem);
                            setCancellationReason('Faculty schedule conflict or university closure.');
                          }}
                          className="p-1.5 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title="Cancel Seminar"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Attendees Modal */}
      {selectedSeminarForAttendees && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[85vh] flex flex-col">
            <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                  Attendee Roster
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedSeminarForAttendees.title}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Total Confirmed Attendees: {attendees.filter(a => a.status === 'confirmed').length}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={`/api/organizer/attendees/${selectedSeminarForAttendees.id}/export`}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </a>
                <button
                  onClick={() => setSelectedSeminarForAttendees(null)}
                  className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 border-b border-slate-100 dark:border-slate-800">
              <input
                type="text"
                value={attendeeSearch}
                onChange={e => setAttendeeSearch(e.target.value)}
                placeholder="Search attendee by name, ticket code, or department..."
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="overflow-y-auto p-4 flex-1">
              {attendeesLoading ? (
                <div className="py-8 text-center text-xs text-slate-400">Loading attendee roster...</div>
              ) : attendees.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No registrations found for this event.
                </div>
              ) : (
                <div className="space-y-2">
                  {attendees
                    .filter(a =>
                      a.participantName.toLowerCase().includes(attendeeSearch.toLowerCase()) ||
                      a.ticketCode.toLowerCase().includes(attendeeSearch.toLowerCase()) ||
                      a.department.toLowerCase().includes(attendeeSearch.toLowerCase())
                    )
                    .map(a => (
                      <div
                        key={a.id}
                        className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 dark:text-white">
                              {a.participantName}
                            </span>
                            <span className="font-mono text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                              {a.ticketCode}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {a.participantEmail} • {a.department} ({a.yearOfStudy})
                          </p>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            a.status === 'confirmed'
                              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                              : 'bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                          }`}
                        >
                          {a.status}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Cancellation Modal */}
      {cancellingSeminar && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-rose-600">
              <ShieldAlert className="w-5 h-5" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Cancel Seminar
              </h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Are you sure you want to cancel <strong>"{cancellingSeminar.title}"</strong>? Registered attendees will be notified and seats released.
            </p>
            <form onSubmit={handleCancelSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Cancellation Reason *
                </label>
                <textarea
                  required
                  rows={3}
                  value={cancellationReason}
                  onChange={e => setCancellationReason(e.target.value)}
                  placeholder="e.g. Speaker flight delay, departmental rescheduling..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCancellingSeminar(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold"
                >
                  Nevermind
                </button>
                <button
                  type="submit"
                  disabled={cancellationSubmitting}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
                >
                  {cancellationSubmitting ? 'Cancelling...' : 'Confirm Cancellation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create / Edit Seminar Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingSeminar ? 'Edit Seminar Details' : 'Create & Publish New Seminar'}
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSeminar} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Seminar Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Deep Learning in Healthcare and Radiology"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Category *
                  </label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Format *
                  </label>
                  <select
                    value={formData.format}
                    onChange={e => setFormData({ ...formData, format: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="In-Person">In-Person</option>
                    <option value="Online">Online</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Target Level *
                  </label>
                  <select
                    value={formData.level}
                    onChange={e => setFormData({ ...formData, level: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="All Levels">All Levels</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Start Time *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.startTime}
                    onChange={e => setFormData({ ...formData, startTime: e.target.value })}
                    placeholder="10:00 AM"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    End Time *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.endTime}
                    onChange={e => setFormData({ ...formData, endTime: e.target.value })}
                    placeholder="01:00 PM"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Venue / Location *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.venue}
                    onChange={e => setFormData({ ...formData, venue: e.target.value })}
                    placeholder="e.g. Auditorium Hall 1"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Total Seats Capacity *
                  </label>
                  <input
                    type="number"
                    required
                    min={5}
                    max={1000}
                    value={formData.totalSeats}
                    onChange={e => setFormData({ ...formData, totalSeats: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Short Description *
                </label>
                <input
                  type="text"
                  required
                  value={formData.shortDescription}
                  onChange={e => setFormData({ ...formData, shortDescription: e.target.value })}
                  placeholder="A concise 1-2 sentence overview for seminar cards..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Full Syllabus & Description *
                </label>
                <textarea
                  required
                  rows={3}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detailed academic overview..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              {/* Speaker fields */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <p className="font-bold text-indigo-600 dark:text-indigo-400">Speaker Profile</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    required
                    value={formData.speakerName}
                    onChange={e => setFormData({ ...formData, speakerName: e.target.value })}
                    placeholder="Speaker Name"
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    value={formData.speakerDesignation}
                    onChange={e => setFormData({ ...formData, speakerDesignation: e.target.value })}
                    placeholder="Designation"
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    value={formData.speakerOrg}
                    onChange={e => setFormData({ ...formData, speakerOrg: e.target.value })}
                    placeholder="Organization"
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
                >
                  {editingSeminar ? 'Save Changes' : 'Publish Seminar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
