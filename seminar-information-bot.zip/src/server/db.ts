import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Seminar, Registration, Announcement, NotificationItem, DashboardStats } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE_PATH = path.resolve(__dirname, '../../data/db.json');

interface DatabaseSchema {
  seminars: Seminar[];
  registrations: Registration[];
  announcements: Announcement[];
  notifications: NotificationItem[];
}

function readDb(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE_PATH)) {
      const defaultData: DatabaseSchema = {
        seminars: [],
        registrations: [],
        announcements: [],
        notifications: [],
      };
      fs.mkdirSync(path.dirname(DB_FILE_PATH), { recursive: true });
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(defaultData, null, 2), 'utf-8');
      return defaultData;
    }
    const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch (error) {
    console.error('Error reading database file:', error);
    return {
      seminars: [],
      registrations: [],
      announcements: [],
      notifications: [],
    };
  }
}

function writeDb(data: DatabaseSchema): void {
  try {
    fs.mkdirSync(path.dirname(DB_FILE_PATH), { recursive: true });
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error writing to database file:', error);
  }
}

export const db = {
  // Seminars
  getSeminars(filters?: {
    category?: string;
    level?: string;
    format?: string;
    status?: string;
    search?: string;
  }): Seminar[] {
    const data = readDb();
    let result = data.seminars;

    if (filters?.status && filters.status !== 'all') {
      result = result.filter(s => s.status === filters.status);
    }
    if (filters?.category && filters.category !== 'all') {
      result = result.filter(s => s.category.toLowerCase() === filters.category!.toLowerCase());
    }
    if (filters?.level && filters.level !== 'all') {
      result = result.filter(s => s.level.toLowerCase() === filters.level!.toLowerCase());
    }
    if (filters?.format && filters.format !== 'all') {
      result = result.filter(s => s.format.toLowerCase() === filters.format!.toLowerCase());
    }
    if (filters?.search && filters.search.trim()) {
      const q = filters.search.toLowerCase().trim();
      result = result.filter(
        s =>
          s.title.toLowerCase().includes(q) ||
          s.speaker.name.toLowerCase().includes(q) ||
          s.category.toLowerCase().includes(q) ||
          s.shortDescription.toLowerCase().includes(q) ||
          s.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return result;
  },

  getSeminarById(id: string): Seminar | undefined {
    const data = readDb();
    return data.seminars.find(s => s.id === id);
  },

  createSeminar(seminarData: Omit<Seminar, 'id' | 'registeredCount' | 'availableSeats' | 'createdAt'>): Seminar {
    const data = readDb();
    const newId = `sem-${Date.now().toString().slice(-4)}`;
    const newSeminar: Seminar = {
      ...seminarData,
      id: newId,
      registeredCount: 0,
      availableSeats: seminarData.totalSeats,
      createdAt: new Date().toISOString(),
    };
    data.seminars.unshift(newSeminar);
    writeDb(data);
    return newSeminar;
  },

  updateSeminar(id: string, updates: Partial<Seminar>): Seminar | null {
    const data = readDb();
    const idx = data.seminars.findIndex(s => s.id === id);
    if (idx === -1) return null;

    const existing = data.seminars[idx];
    const updated: Seminar = {
      ...existing,
      ...updates,
      // Ensure seat counts remain logically sound if total seats changes
      totalSeats: updates.totalSeats !== undefined ? updates.totalSeats : existing.totalSeats,
      availableSeats:
        updates.totalSeats !== undefined
          ? Math.max(0, updates.totalSeats - existing.registeredCount)
          : updates.availableSeats !== undefined
          ? updates.availableSeats
          : existing.availableSeats,
    };

    data.seminars[idx] = updated;
    writeDb(data);
    return updated;
  },

  cancelSeminar(id: string, cancellationReason: string): { seminar: Seminar; affectedCount: number } | null {
    const data = readDb();
    const idx = data.seminars.findIndex(s => s.id === id);
    if (idx === -1) return null;

    const seminar = data.seminars[idx];
    seminar.status = 'cancelled';
    seminar.cancellationReason = cancellationReason || 'Event cancelled by organizer.';

    // Notify registered attendees and mark registrations as cancelled
    let affectedCount = 0;
    const now = new Date().toISOString();
    data.registrations = data.registrations.map(r => {
      if (r.seminarId === id && r.status === 'confirmed') {
        affectedCount++;
        // Add individual notification
        data.notifications.unshift({
          id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          userEmail: r.participantEmail,
          title: `Important: Seminar Cancelled - ${seminar.title}`,
          message: `The seminar '${seminar.title}' scheduled for ${seminar.date} has been cancelled by the organizer. Reason: ${seminar.cancellationReason}`,
          type: 'cancellation',
          seminarId: seminar.id,
          read: false,
          createdAt: now,
        });
        return { ...r, status: 'cancelled', cancellationReason };
      }
      return r;
    });

    data.seminars[idx] = seminar;
    writeDb(data);
    return { seminar, affectedCount };
  },

  // Registrations
  getRegistrations(filters?: { userEmail?: string; seminarId?: string; status?: string }): Registration[] {
    const data = readDb();
    let list = data.registrations;

    if (filters?.userEmail) {
      list = list.filter(r => r.participantEmail.toLowerCase() === filters.userEmail!.toLowerCase());
    }
    if (filters?.seminarId) {
      list = list.filter(r => r.seminarId === filters.seminarId);
    }
    if (filters?.status && filters.status !== 'all') {
      list = list.filter(r => r.status === filters.status);
    }
    return list;
  },

  registerForSeminar(input: {
    seminarId: string;
    participantName: string;
    participantEmail: string;
    institution: string;
    department: string;
    yearOfStudy: string;
    phone?: string;
  }): { success: boolean; registration?: Registration; message: string } {
    const data = readDb();
    const seminarIdx = data.seminars.findIndex(s => s.id === input.seminarId);

    if (seminarIdx === -1) {
      return { success: false, message: 'Seminar not found.' };
    }

    const seminar = data.seminars[seminarIdx];

    if (seminar.status !== 'published') {
      return { success: false, message: `Cannot register: Seminar is currently ${seminar.status}.` };
    }

    if (seminar.availableSeats <= 0) {
      return { success: false, message: 'Registration full: No remaining seats available for this seminar.' };
    }

    // Check registration deadline
    const deadline = new Date(seminar.registrationDeadline);
    if (!isNaN(deadline.getTime()) && new Date() > deadline) {
      return { success: false, message: 'Registration closed: The registration deadline has passed.' };
    }

    // Prevent duplicate registrations for the same seminar and email
    const duplicate = data.registrations.find(
      r =>
        r.seminarId === input.seminarId &&
        r.participantEmail.toLowerCase() === input.participantEmail.toLowerCase() &&
        r.status === 'confirmed'
    );

    if (duplicate) {
      return {
        success: false,
        message: `You are already registered for this seminar (Ticket Code: ${duplicate.ticketCode}).`,
      };
    }

    // Deduct available seat
    seminar.availableSeats -= 1;
    seminar.registeredCount += 1;
    data.seminars[seminarIdx] = seminar;

    const regId = `REG-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const ticketCode = `PASS-${seminar.category.slice(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    const newRegistration: Registration = {
      id: regId,
      seminarId: seminar.id,
      seminarTitle: seminar.title,
      seminarDate: seminar.date,
      seminarTime: `${seminar.startTime} - ${seminar.endTime}`,
      seminarVenue: seminar.venue,
      seminarFormat: seminar.format,
      participantName: input.participantName,
      participantEmail: input.participantEmail,
      institution: input.institution,
      department: input.department,
      yearOfStudy: input.yearOfStudy,
      phone: input.phone || '',
      status: 'confirmed',
      registeredAt: now,
      ticketCode,
    };

    data.registrations.unshift(newRegistration);

    // Create user notification
    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      userEmail: input.participantEmail,
      title: 'Registration Confirmed!',
      message: `You are registered for '${seminar.title}' on ${seminar.date}. Your ticket code is ${ticketCode}.`,
      type: 'registration',
      seminarId: seminar.id,
      read: false,
      createdAt: now,
    });

    writeDb(data);
    return { success: true, registration: newRegistration, message: 'Registration confirmed successfully!' };
  },

  cancelRegistration(registrationId: string, userEmail: string): { success: boolean; message: string } {
    const data = readDb();
    const regIdx = data.registrations.findIndex(r => r.id === registrationId);

    if (regIdx === -1) {
      return { success: false, message: 'Registration record not found.' };
    }

    const reg = data.registrations[regIdx];

    if (reg.status === 'cancelled') {
      return { success: false, message: 'This registration is already cancelled.' };
    }

    // Restore seat
    const seminarIdx = data.seminars.findIndex(s => s.id === reg.seminarId);
    if (seminarIdx !== -1) {
      const sem = data.seminars[seminarIdx];
      sem.availableSeats = Math.min(sem.totalSeats, sem.availableSeats + 1);
      sem.registeredCount = Math.max(0, sem.registeredCount - 1);
      data.seminars[seminarIdx] = sem;
    }

    reg.status = 'cancelled';
    reg.cancellationReason = 'Cancelled by participant';
    data.registrations[regIdx] = reg;

    // Add cancellation notification
    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      userEmail: userEmail || reg.participantEmail,
      title: 'Registration Cancelled',
      message: `Your registration for '${reg.seminarTitle}' has been cancelled. Available seats were updated.`,
      type: 'update',
      seminarId: reg.seminarId,
      read: false,
      createdAt: new Date().toISOString(),
    });

    writeDb(data);
    return { success: true, message: 'Registration successfully cancelled.' };
  },

  // Announcements
  getAnnouncements(): Announcement[] {
    const data = readDb();
    return data.announcements.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  },

  createAnnouncement(announcementData: Omit<Announcement, 'id' | 'createdAt'>): Announcement {
    const data = readDb();
    const newAnnouncement: Announcement = {
      ...announcementData,
      id: `ann-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString(),
    };
    data.announcements.unshift(newAnnouncement);

    // Broadcast notification to all
    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      title: `Campus Announcement: ${newAnnouncement.title}`,
      message: newAnnouncement.content.slice(0, 140) + '...',
      type: 'announcement',
      read: false,
      createdAt: new Date().toISOString(),
    });

    writeDb(data);
    return newAnnouncement;
  },

  // Notifications
  getNotifications(userEmail?: string): NotificationItem[] {
    const data = readDb();
    if (!userEmail) return data.notifications;
    return data.notifications.filter(n => !n.userEmail || n.userEmail.toLowerCase() === userEmail.toLowerCase());
  },

  markNotificationRead(id: string): boolean {
    const data = readDb();
    const idx = data.notifications.findIndex(n => n.id === id);
    if (idx === -1) return false;
    data.notifications[idx].read = true;
    writeDb(data);
    return true;
  },

  markAllNotificationsRead(userEmail?: string): void {
    const data = readDb();
    data.notifications = data.notifications.map(n => {
      if (!userEmail || !n.userEmail || n.userEmail.toLowerCase() === userEmail.toLowerCase()) {
        return { ...n, read: true };
      }
      return n;
    });
    writeDb(data);
  },

  // Dashboard Stats
  getStats(userEmail?: string): DashboardStats {
    const data = readDb();
    const now = new Date().toISOString().slice(0, 10);

    const upcomingSeminars = data.seminars.filter(s => s.status === 'published' && s.date >= now).length;
    const completedSeminars = data.seminars.filter(s => s.status === 'completed' || s.date < now).length;
    const availableRegistrations = data.seminars.filter(s => s.status === 'published' && s.availableSeats > 0 && s.date >= now).length;

    let myRegisteredSeminars = 0;
    if (userEmail) {
      myRegisteredSeminars = data.registrations.filter(
        r => r.participantEmail.toLowerCase() === userEmail.toLowerCase() && r.status === 'confirmed'
      ).length;
    }

    const totalRegistrationsCount = data.registrations.filter(r => r.status === 'confirmed').length;

    return {
      upcomingSeminars,
      availableRegistrations,
      myRegisteredSeminars,
      completedSeminars,
      totalRegistrationsCount,
    };
  },
};
