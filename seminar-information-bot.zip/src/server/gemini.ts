import { GoogleGenAI } from '@google/genai';
import { db } from './db.js';
import { Seminar } from '../types/index.js';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export interface ChatResponsePayload {
  reply: string;
  referencedSeminarIds: string[];
  suggestedQuestions: string[];
}

export async function askSeminarBot(params: {
  message: string;
  conversationHistory: { role: 'user' | 'assistant'; content: string }[];
  language?: 'en' | 'hi' | 'mr';
}): Promise<ChatResponsePayload> {
  const { message, conversationHistory, language = 'en' } = params;
  const allSeminars = db.getSeminars();

  // Create compact snapshot of verified seminars for grounding
  const verifiedSeminarContext = allSeminars.map(s => ({
    id: s.id,
    title: s.title,
    category: s.category,
    format: s.format,
    level: s.level,
    date: s.date,
    time: `${s.startTime} - ${s.endTime}`,
    venue: s.venue,
    speaker: `${s.speaker.name} (${s.speaker.designation}, ${s.speaker.organization})`,
    organizer: `${s.organizer.name} (${s.organizer.department})`,
    availableSeats: s.availableSeats,
    totalSeats: s.totalSeats,
    registrationDeadline: s.registrationDeadline,
    status: s.status,
    prerequisites: s.prerequisites,
    shortDescription: s.shortDescription,
  }));

  const systemInstruction = `You are the official "Seminar Information Bot" for the college/university campus.
Your job is to provide accurate, verified information about college seminars, event schedules, venues, prerequisites, registration policies, and explain computer science / engineering topics in clear, student-friendly terms.

IMPORTANT RULES & CONSTRAINTS:
1. TRUTH & GROUNDING: You have access to the OFFICIAL, VERIFIED SEMINAR DATABASE snapshot below.
   - For ANY question regarding scheduled seminars, dates, speakers, venues, available seats, or registration deadlines, you MUST rely SOLELY on this verified database.
   - NEVER invent, extrapolate, or hallucinate seminar names, speakers, dates, venues, or links that do not exist in the database.
   - If the user asks for a seminar that is not in the database (e.g. "Is there a blockchain seminar?"), state clearly: "No seminar on this topic is currently scheduled in the official college directory."
2. TECHNICAL CONCEPT EXPLANATION:
   - When asked to explain technical concepts (e.g. "Explain cloud computing in simple language", "What is the difference between a workshop and a seminar?", "What is RAG?"), provide crystal-clear, structured answers using:
     - Clear headings
     - Bullet points
     - Beginner-friendly analogies
     - Actionable steps or prerequisites
3. MULTI-LINGUAL SUPPORT:
   - Default to English, but if the user writes in Hindi (हिन्दी) or Marathi (मराठी) or requests it, reply fluently and accurately in that language with correct terminology.
4. REFERENCED SEMINARS:
   - Whenever you discuss or recommend specific seminars from the database, include their exact IDs in the "referencedSeminarIds" JSON array so the user interface can display interactive registration cards.
5. SUGGESTED QUESTIONS:
   - Always return 3 concise, highly relevant follow-up questions in "suggestedQuestions".

VERIFIED DATABASE SNAPSHOT (CURRENT DATE IS OCTOBER 2026):
${JSON.stringify(verifiedSeminarContext, null, 2)}

OUTPUT FORMAT:
Respond ONLY with a valid JSON object matching this structure:
{
  "reply": "Your markdown formatted response string here.",
  "referencedSeminarIds": ["sem-101", ...],
  "suggestedQuestions": ["Question 1?", "Question 2?", "Question 3?"]
}`;

  const client = getAiClient();

  if (client) {
    try {
      // Build conversation turns
      const promptContents = [
        ...conversationHistory.slice(-6).map(h => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.content}`),
        `User: ${message}`,
      ].join('\n\n');

      const response = await client.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptContents,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2, // low temperature for high factual accuracy
        },
      });

      const responseText = response.text?.trim() || '';
      try {
        const parsed = JSON.parse(responseText) as ChatResponsePayload;
        if (parsed.reply) {
          return {
            reply: parsed.reply,
            referencedSeminarIds: Array.isArray(parsed.referencedSeminarIds) ? parsed.referencedSeminarIds : [],
            suggestedQuestions: Array.isArray(parsed.suggestedQuestions)
              ? parsed.suggestedQuestions
              : ['How do I register for this seminar?', 'What are the prerequisites?', 'Show more upcoming seminars'],
          };
        }
      } catch (err) {
        console.warn('Could not parse Gemini JSON, fallback to raw text:', err);
        return {
          reply: responseText,
          referencedSeminarIds: extractMatchingIds(responseText, allSeminars),
          suggestedQuestions: [
            'How do I register for a seminar?',
            'Which seminars are suitable for beginners?',
            'What seminars are scheduled this week?',
          ],
        };
      }
    } catch (apiError) {
      console.error('Gemini API call error:', apiError);
      // Fall through to deterministic offline college rule-engine
    }
  }

  // Deterministic local smart fallback in case API key is missing or network failure
  return fallbackRuleEngine(message, allSeminars, language);
}

function extractMatchingIds(text: string, seminars: Seminar[]): string[] {
  const ids: string[] = [];
  for (const s of seminars) {
    if (text.includes(s.title) || text.includes(s.id)) {
      ids.push(s.id);
    }
  }
  return ids;
}

function fallbackRuleEngine(
  message: string,
  seminars: Seminar[],
  language: 'en' | 'hi' | 'mr'
): ChatResponsePayload {
  const query = message.toLowerCase();

  // 1. AI / ML
  if (query.includes('artificial intelligence') || query.includes('ai') || query.includes('llm') || query.includes('machine learning')) {
    const aiSem = seminars.filter(s => s.category === 'Artificial Intelligence' || s.category === 'Machine Learning');
    return {
      reply: `### Artificial Intelligence & Machine Learning Seminars

Here are the verified AI seminars available on campus:

${aiSem
  .map(
    s =>
      `* **${s.title}** (${s.date})\n  * **Speaker:** ${s.speaker.name} (${s.speaker.organization})\n  * **Venue:** ${s.venue}\n  * **Seats Remaining:** ${s.availableSeats} of ${s.totalSeats}\n  * **Level:** ${s.level}\n  * **Prerequisites:** ${s.prerequisites.join(', ')}`
  )
  .join('\n\n')}

You can register directly using the seminar cards below.`,
      referencedSeminarIds: aiSem.map(s => s.id),
      suggestedQuestions: [
        'What are the prerequisites for the Gen AI seminar?',
        'Who is the speaker Priya Sharma?',
        'How do I register for an AI seminar?',
      ],
    };
  }

  // 2. Cloud computing explanation
  if (query.includes('cloud computing') && (query.includes('explain') || query.includes('simple') || query.includes('what is'))) {
    const cloudSem = seminars.filter(s => s.category === 'Cloud Computing' || s.category === 'Cybersecurity');
    return {
      reply: `### Cloud Computing Explained in Simple Language

Imagine instead of buying an expensive power generator for your home, you simply plug into the electricity wall socket and pay for what you consume. **Cloud computing works the exact same way for computing power.**

Instead of storing files, databases, and heavy software on your personal laptop or physical campus servers:
* **On-Demand Access:** You rent computing servers, storage, and GPUs over the internet from providers like Google Cloud, AWS, or Azure.
* **Pay-As-You-Go:** You only pay for the minutes or gigabytes your applications actively use.
* **Instant Scalability:** If 100,000 students log in to check exam results, cloud servers automatically spin up 10 extra machines in seconds to avoid crashing.

#### Core Service Models:
1. **IaaS (Infrastructure as a Service):** Renting virtual machines and disks (e.g. AWS EC2, Google Compute Engine).
2. **PaaS (Platform as a Service):** Deploying your code without managing operating systems (e.g. Google Cloud Run, Vercel).
3. **SaaS (Software as a Service):** Complete ready-to-use software delivered over the web (e.g. Google Docs, Gmail).

Relevant upcoming campus seminar on Cloud Security is available below!`,
      referencedSeminarIds: cloudSem.map(s => s.id),
      suggestedQuestions: [
        'What is Zero Trust Architecture?',
        'Which seminars teach cloud computing?',
        'What should I prepare for the cloud security seminar?',
      ],
    };
  }

  // 3. Difference between workshop and seminar
  if (query.includes('difference') && query.includes('workshop') && query.includes('seminar')) {
    return {
      reply: `### Difference Between a Seminar and a Workshop

While both are valuable learning opportunities, they have distinct formats and objectives:

| Feature | Seminar | Workshop |
| :--- | :--- | :--- |
| **Format** | Presentation, lecture, and panel Q&A | Hands-on, practical execution and coding |
| **Audience Role** | Active listeners taking notes and asking questions | Active participants building live projects |
| **Objective** | Conceptual understanding and industry insights | Skill acquisition and practical tool mastery |
| **Group Size** | Large audiences (100–400+ attendees) | Smaller cohorts (20–60 attendees) |
| **Prerequisites** | Conceptual curiosity, minimal setup | Laptops with SDKs, compilers, or IDEs installed |

At our college, our seminars frequently feature interactive demos and live code walkthroughs!`,
      referencedSeminarIds: ['sem-101', 'sem-107'],
      suggestedQuestions: [
        'Which upcoming seminars have hands-on demos?',
        'What should I bring to an in-person seminar?',
        'How do I cancel my registration if I cannot attend?',
      ],
    };
  }

  // 4. Beginner friendly
  if (query.includes('beginner') || query.includes('first year') || query.includes('freshman')) {
    const beginnerSem = seminars.filter(s => s.level === 'Beginner' || s.level === 'All Levels');
    return {
      reply: `### Seminars Recommended for Beginners

The following verified seminars are tailored for students with no prior advanced experience:

${beginnerSem
  .map(
    s =>
      `* **${s.title}** (${s.category})\n  * **Date & Time:** ${s.date} at ${s.startTime}\n  * **Format:** ${s.format}\n  * **Why it's great:** ${s.shortDescription}`
  )
  .join('\n\n')}

All students are welcome to attend without any prerequisite coding tests.`,
      referencedSeminarIds: beginnerSem.map(s => s.id),
      suggestedQuestions: [
        'How do I register for the placement preparation seminar?',
        'What is the dress code and venue for the entrepreneurship seminar?',
        'Will I receive an attendance certificate?',
      ],
    };
  }

  // 5. Registration help
  if (query.includes('register') || query.includes('how to register') || query.includes('ticket')) {
    return {
      reply: `### How to Register for a Seminar

Registering takes less than 30 seconds:

1. **Browse Seminars:** Navigate to the **Explore Seminars** page or click on any seminar card.
2. **Click "Register Now":** Ensure the registration deadline has not passed and seats are available.
3. **Fill Details:** Enter your name, college email, department, and year of study.
4. **Instant Pass:** Once submitted, you immediately receive a verified digital Ticket Code (e.g. \`PASS-ART-8491\`).
5. **View or Cancel:** You can view your ticket, export the calendar invite (.ics), or cancel anytime in **My Registrations**.`,
      referencedSeminarIds: ['sem-101', 'sem-102'],
      suggestedQuestions: [
        'Can I register for multiple seminars?',
        'What happens if an event reaches full capacity?',
        'Where can I find my registered passes?',
      ],
    };
  }

  // Default overview
  const upcoming = seminars.filter(s => s.status === 'published').slice(0, 4);
  return {
    reply: `### Seminar Information Assistant

I can help you explore verified seminars, understand complex computer science concepts, check speaker profiles, and manage your event registrations.

#### Upcoming Highlights in the University Directory:
${upcoming.map(s => `* **${s.title}** on **${s.date}** (${s.availableSeats} seats left)`).join('\n')}

Feel free to ask questions like:
* *"What seminars are available this week?"*
* *"Explain cloud computing in simple language"*
* *"What are the prerequisites for the AI seminar?"*
* *"Which events are suitable for beginners?"*`,
    referencedSeminarIds: upcoming.map(s => s.id),
    suggestedQuestions: [
      'What seminars are scheduled this month?',
      'Which seminars are related to artificial intelligence?',
      'Explain cloud computing in simple language',
    ],
  };
}
