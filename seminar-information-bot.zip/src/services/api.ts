import { Seminar, Registration, Announcement, NotificationItem, DashboardStats, ChatMessage } from '../types/index.js';

export const api = {
  async getSeminars(filters?: {
    category?: string;
    level?: string;
    format?: string;
    status?: string;
    search?: string;
  }): Promise<Seminar[]> {
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.level) params.append('level', filters.level);
    if (filters?.format) params.append('format', filters.format);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);

    const res = await fetch(`/api/seminars?${params.toString()}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch seminars');
    return json.data;
  },

  async getSeminarById(id: string): Promise<Seminar> {
    const res = await fetch(`/api/seminars/${id}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch seminar');
    return json.data;
  },

  async createSeminar(data: any): Promise<Seminar> {
    const res = await fetch('/api/seminars', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to create seminar');
    return json.data;
  },

  async updateSeminar(id: string, data: Partial<Seminar>): Promise<Seminar> {
    const res = await fetch(`/api/seminars/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to update seminar');
    return json.data;
  },

  async cancelSeminar(id: string, reason: string): Promise<any> {
    const res = await fetch(`/api/seminars/${id}/cancel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason }),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to cancel seminar');
    return json.data;
  },

  async getRegistrations(params?: { userEmail?: string; seminarId?: string; status?: string }): Promise<Registration[]> {
    const q = new URLSearchParams();
    if (params?.userEmail) q.append('userEmail', params.userEmail);
    if (params?.seminarId) q.append('seminarId', params.seminarId);
    if (params?.status) q.append('status', params.status);

    const res = await fetch(`/api/registrations?${q.toString()}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch registrations');
    return json.data;
  },

  async registerForSeminar(payload: {
    seminarId: string;
    participantName: string;
    participantEmail: string;
    institution: string;
    department: string;
    yearOfStudy: string;
    phone?: string;
  }): Promise<{ registration: Registration; message: string }> {
    const res = await fetch('/api/registrations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'Registration failed');
    return { registration: json.registration, message: json.message };
  },

  async cancelRegistration(id: string, userEmail: string): Promise<string> {
    const res = await fetch(`/api/registrations/${id}/cancel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userEmail }),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'Cancellation failed');
    return json.message;
  },

  async getAnnouncements(): Promise<Announcement[]> {
    const res = await fetch('/api/announcements');
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch announcements');
    return json.data;
  },

  async createAnnouncement(data: { title: string; content: string; priority?: string; pinned?: boolean }): Promise<Announcement> {
    const res = await fetch('/api/announcements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to post announcement');
    return json.data;
  },

  async getNotifications(userEmail?: string): Promise<NotificationItem[]> {
    const q = userEmail ? `?userEmail=${encodeURIComponent(userEmail)}` : '';
    const res = await fetch(`/api/notifications${q}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch notifications');
    return json.data;
  },

  async markNotificationRead(id: string): Promise<boolean> {
    const res = await fetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
    const json = await res.json();
    return !!json.success;
  },

  async markAllNotificationsRead(userEmail?: string): Promise<void> {
    await fetch('/api/notifications/mark-all-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userEmail }),
    });
  },

  async getStats(userEmail?: string): Promise<DashboardStats> {
    const q = userEmail ? `?userEmail=${encodeURIComponent(userEmail)}` : '';
    const res = await fetch(`/api/stats${q}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to fetch stats');
    return json.data;
  },

  async sendChatMessage(payload: {
    message: string;
    conversationHistory: { role: 'user' | 'assistant'; content: string }[];
    language?: 'en' | 'hi' | 'mr';
  }): Promise<{ reply: string; referencedSeminarIds: string[]; suggestedQuestions: string[] }> {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to query AI assistant');
    return json.data;
  },
};
