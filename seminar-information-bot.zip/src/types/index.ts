export type SeminarCategory =
  | 'Artificial Intelligence'
  | 'Machine Learning'
  | 'Data Science'
  | 'Cloud Computing'
  | 'Cybersecurity'
  | 'Web Development'
  | 'Mobile App Development'
  | 'Internet of Things'
  | 'Entrepreneurship'
  | 'Career Development'
  | 'Research and Innovation';

export type SeminarFormat = 'In-Person' | 'Online' | 'Hybrid';
export type SeminarLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
export type SeminarStatus = 'published' | 'draft' | 'cancelled' | 'completed';

export interface AgendaItem {
  time: string;
  sessionTitle: string;
  speaker?: string;
  description?: string;
}

export interface SpeakerInfo {
  name: string;
  designation: string;
  organization: string;
  bio: string;
  avatarUrl?: string;
  linkedin?: string;
}

export interface OrganizerInfo {
  id: string;
  name: string;
  department: string;
  email: string;
  phone?: string;
}

export interface Seminar {
  id: string;
  title: string;
  slug: string;
  category: SeminarCategory;
  format: SeminarFormat;
  level: SeminarLevel;
  shortDescription: string;
  description: string;
  learningObjectives: string[];
  prerequisites: string[];
  eligibility: string;
  agenda: AgendaItem[];
  speaker: SpeakerInfo;
  organizer: OrganizerInfo;
  date: string; // YYYY-MM-DD
  startTime: string;
  endTime: string;
  venue: string;
  meetingLink?: string;
  totalSeats: number;
  availableSeats: number;
  registeredCount: number;
  registrationDeadline: string; // ISO date
  status: SeminarStatus;
  cancellationReason?: string;
  bannerGradient?: string;
  tags: string[];
  isFeatured?: boolean;
  createdAt: string;
}

export interface Registration {
  id: string;
  seminarId: string;
  seminarTitle: string;
  seminarDate: string;
  seminarTime: string;
  seminarVenue: string;
  seminarFormat: SeminarFormat;
  participantName: string;
  participantEmail: string;
  institution: string;
  department: string;
  yearOfStudy: string;
  phone?: string;
  status: 'confirmed' | 'cancelled' | 'attended';
  registeredAt: string;
  cancellationReason?: string;
  ticketCode: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  priority: 'normal' | 'high' | 'urgent';
  author: string;
  department: string;
  createdAt: string;
  pinned?: boolean;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  userEmail?: string;
  title: string;
  message: string;
  type: 'registration' | 'reminder' | 'update' | 'announcement' | 'cancellation';
  seminarId?: string;
  read: boolean;
  createdAt: string;
}

export type UserRole = 'student' | 'organizer' | 'admin' | 'speaker';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  institution: string;
  department: string;
  yearOfStudy?: string;
  phone?: string;
  interests: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  referencedSeminars?: string[];
  suggestedQuestions?: string[];
}

export interface DashboardStats {
  upcomingSeminars: number;
  availableRegistrations: number;
  myRegisteredSeminars: number;
  completedSeminars: number;
  totalRegistrationsCount: number;
}
